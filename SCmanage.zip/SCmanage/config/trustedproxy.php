<?php

return [
    'proxies' => null,
    'headers' => Illuminate\Http\Request::HEADER_X_FORWARDED_ALL,
];